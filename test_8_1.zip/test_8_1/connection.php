<?php
$db = " kandos1_db";
$host ="localhost";
$user = "root";
$pass = "";
$con = mysql_connect($host,$user,$pass);
$db_select = mysql_select_db($db,$con);

?>